/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.025
 *
 * Created on 1 de abril de 2024, 17:26
 */

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <math.h>

using namespace std;

/*
 * Projeto para calcular a área total e o volume:
 *  
 * OBJETOS 3D
 * cubo lado area volume-
 * esfera raio area volume -
 * paralelepipedo l1 l2 l3 area volume - 
 * cilindro raio altura area volume -
 * cone raio altura
 * 
 * OBJETOS 2D
 * quadrado lado
 * circulo raio
 * retangulo l1 l2
 * triangulo base altura
 * 
 * uma cena gráfica com valores lidos de um arquivo-texto
 */
int main(int argc, char** argv) {
    
    int cont3d = 0;
    int contNull = 0;
    int cont2d = 0;
    float r = 0, h = 0, v = 0, a = 0, c = 0, l = 0;
    const float pi = 3.14159265358979323846;
    string solido;

    ifstream arquivo("cenografica.txt");

    if (!arquivo.is_open()) {
        cout << "Erro: arquivo não existe" << endl;
        return 1;
    }


    while (arquivo >> solido && solido != "fim") {

        if (solido == "cubo" || solido == "esfera" || solido == "paralelepipedo" || solido == "cilindro" || solido == "cone") {

            cout << "\n\t Objeto Tri-Dimensional (3D)";

            if (solido == "cubo") {

                cont3d++;
                arquivo >> h;

                // Calculando a área
                a = h * h;
                // Calculando o volume
                v = a * h;

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Cubo";
                cout << "\n\t Lados: " << h;
                cout << "\n\t Área: " << a;
                cout << "\n\t Volume: " << v;
                cout << "\n\t -------------------";

            }

            if (solido == "paralelepípedo") {

                cont3d++;
                arquivo >> h;
                arquivo >> l;
                arquivo >> c;

                // Calculando a área
                a = 2 * (c * l + c * h + l * h);
                // Calculando o volume
                v = c * l * h;

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Paralelepípedo";
                cout << "\n\t Altura: " << h;
                cout << "\n\t Largura: " << l;
                cout << "\n\t Comprimento: " << c;
                cout << "\n\t Área: " << a;
                cout << "\n\t Volume: " << v;
                cout << "\n\t -------------------";

            }

            if (solido == "cilindro") {

                cont3d++;
                arquivo >> r;
                arquivo >> h;

                // Calculando a área da superfície
                a = 2 * pi * r * (r + h);
                // Calculando o volume
                v = pi * r * r * h;

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Cilindro";
                cout << "\n\t Raio: " << r;
                cout << "\n\t Altura: " << h;
                cout << "\n\t Área: " << a;
                cout << "\n\t Volume: " << v;
                cout << "\n\t -------------------";

            }

            if (solido == "esfera") {

                cont3d++;
                arquivo >> r;

                // Calculando a área da superfície
                a = 4 * pi * r * r;

                // Calculando o volume
                v = (4.0 / 3.0) * pi * r * r * r;

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Esfera";
                cout << "\n\t Raio: " << r;
                cout << "\n\t Área: " << a;
                cout << "\n\t Volume: " << v;
                cout << "\n\t -------------------";


            }

            if (solido == "cone") {

                cont3d++;
                arquivo >> r;
                arquivo >> h;

                // Calculando a área da superfície
                h = sqrt(pow(h, 2) + pow(r, 2));
                a = pi * r * (r + h);

                // Calculando o volume
                v = (1.0 / 3.0) * pi * pow(r, 2) * h;

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Cone";
                cout << "\n\t Raio: " << r;
                cout << "\n\t Altura: " << h;
                cout << "\n\t Área: " << a;
                cout << "\n\t Volume: " << v;
                cout << "\n\t -------------------";


            }
        
        } else if (solido == "quadrado" || solido == "circulo" || solido == "retangulo" || solido == "triangulo") {
            
            cout << "\n\t Objeto Bi-Dimensional (2D)";

            if (solido == "quadrado") {
                
                cont2d ++;
                arquivo >> h;

                // Calculando a área
                a = h * h;

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Quadrado";
                cout << "\n\t Lados: " << h;
                cout << "\n\t Área: " << a;
                cout << "\n\t -------------------";

            }

            if (solido == "circulo") {

                cont2d ++;
                arquivo >> r;

                // Calculando a área da superfície
                a = pi * (r * r);

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Circulo";
                cout << "\n\t Raio: " << r;
                cout << "\n\t Área: " << a;
                cout << "\n\t -------------------";

            }

            if (solido == "retangulo") {

                cont2d ++;
                arquivo >> l;
                arquivo >> c;

                // Calculando a áreas
                a = l * c;

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Retangulo";
                cout << "\n\t Largura: " << l;
                cout << "\n\t Comprimento: " << c;
                cout << "\n\t Área: " << a;
                cout << "\n\t -------------------";

            }

            if (solido == "triangulo") {

                cont2d ++;
                arquivo >> l;
                arquivo >> h;

                // Calculando a área da superfície
                a = 0.5 * l * h;

                cout << "\n\t -------------------";
                cout << "\n\t Sólido: Cone";
                cout << "\n\t Base: " << l;
                cout << "\n\t Altura: " << h;
                cout << "\n\t Área: " << a;
                cout << "\n\t -------------------";


            }

        }

    }

    cout << "\n\t -------------------------------------------------------";
    cout << "\n\t Foram encontrados "<<cont2d<<" objetos bi-dimensionais";
    cout << "\n\t Foram encontrados "<<cont3d<<" objetos tri-dimensionais";
    cout << "\n\t Fim do programa;";
    cout << "\n\t -------------------------------------------------------";



    return 0;
}

